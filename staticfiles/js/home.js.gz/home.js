


$(document).ready(function(){

    // const spinnerBox = document.getElementById('spinnerBox');
    // const dataBox = document.getElementById('dataBox');

    // $.ajax({
    //     type: 'GET',
    //     url: '',
    //     success: function(response){
    //         console.log(response)
    //     },
    //     error: function(error){
    //         console.log(error)
    //     }
    
    
    // })

    NProgress.start();
    NProgress.done();

    

});

